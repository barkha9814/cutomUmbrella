import blueUmbrella from './asset/images/Blue umbrella.png'
import yellowUmbrella from './asset/images/Yello umbrella.png'
import pinkUmbrella from './asset/images/Pink umbrella.png'
import uploadIcon from './asset/icons/upload_icon.svg'
import loader from './asset/icons/loader_icon.svg'
import './App.css';
import { useState } from 'react';

function App() {


  const [umbrellaColor, setUmbrella] = useState(blueUmbrella)
  const [bgColor, setBgColor] = useState("#d1edf3")
  const [btnColor, setBtnColor] = useState("#1eafe9")
  const [btnShadow, setBtnShadow] = useState("#1eafe9")
  const [loading, setLoading] = useState(false)

  const changeUmbrellaColor = (umbrellaColor, bgColor, BtnColor) => {
    let time = 0
    clearTimeout(time)
    setLoading(true)
    setBgColor(bgColor)
    setBtnColor(BtnColor)
    time = setTimeout(() => {
      setLoading(false)
      setUmbrella(umbrellaColor)
    }, 2000);
  }
  return (
    <div className="App">
      <header className="App-header" style={{background: bgColor}}>
        {
          loading === true ?
          <img src={loader} className="loader" alt="loader" />
          :
          <img src={umbrellaColor} className="App-logo" alt="logo" />
        }
        <div className='colorWrapper'>
          <h1 className='heading'>
            Custom Umbrella
          </h1>
          <div className='colorBtnWrapper'>
              <button className='blueBtn' onClick={() => changeUmbrellaColor(blueUmbrella, "#d1edf3", "#1eafe9")}></button>
              <button className='yellowBtn' onClick={() => changeUmbrellaColor(yellowUmbrella, "#f5efd8db", "#eec721db")}></button>
              <button className='pinkBtn' style={{boxShadow: btnShadow}} onClick={() => changeUmbrellaColor(pinkUmbrella, "#f6e5f0", "#e10995", "0px 0px 5px 7px #f170b1")}></button>
          </div>
          <div className='infoWrapper'>
            <p className='info1'>Custommize your umbrella</p>
            <p className='info2'>Upload a logo for an instant preview</p>
            <p className='info3'>.png and .jpg files only. Max file size 5MB</p>
          </div>
          <button className='UploadLogoBtn'style={{background: btnColor}}>
            <img src={loading === true ? loader : uploadIcon} className={loading === true ? 'loaderIcon' : 'uploadIcon' } />UPLOAD LOGO
          </button>
        </div>
      </header>
    </div>
  );
}

export default App;
